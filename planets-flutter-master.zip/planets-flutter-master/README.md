# planets

An example for a rich ui on Flutter

## Origin

I saw a nice UI example in UpLabs.com (https://www.uplabs.com/posts/space-travel-ui) and I decided to try this:

![](https://cdn.dribbble.com/users/914722/screenshots/3426198/attachments/749973/treva_2x.png)

Thanks to @realvjy (the author of the design) for the help on implementing it


