package com.bartech.sales.sa.ui.mainscreen;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/31/2018.
 */

public interface MainMvpView extends MvpView {

}
