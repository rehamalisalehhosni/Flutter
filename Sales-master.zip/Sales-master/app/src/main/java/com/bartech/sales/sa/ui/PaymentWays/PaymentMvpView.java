package com.bartech.sales.sa.ui.PaymentWays;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/17/2018.
 */

public interface PaymentMvpView extends MvpView {

    void openCashPaymentActivity();

    void openCheckPaymentActivity();



}
