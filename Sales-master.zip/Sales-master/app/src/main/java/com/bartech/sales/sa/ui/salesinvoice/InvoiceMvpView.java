package com.bartech.sales.sa.ui.salesinvoice;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/18/2018.
 */

public interface InvoiceMvpView extends MvpView {

    void openInvoiceActivity();

    void onShowSalesInvoiceClicked();
}
