package com.bartech.sales.sa.ui.customer;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/15/2018.
 */

public interface CustomerMvpView extends MvpView {

    void openSalesActivity();
}
