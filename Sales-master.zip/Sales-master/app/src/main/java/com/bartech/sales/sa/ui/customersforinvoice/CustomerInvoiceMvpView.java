package com.bartech.sales.sa.ui.customersforinvoice;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/15/2018.
 */

public interface CustomerInvoiceMvpView extends MvpView {

    void openSalesActivity();
}
