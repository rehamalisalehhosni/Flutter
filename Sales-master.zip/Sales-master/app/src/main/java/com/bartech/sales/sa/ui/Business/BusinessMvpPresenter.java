package com.bartech.sales.sa.ui.Business;

import com.bartech.sales.sa.ui.base.MvpPresenter;

/**
 * Created by Ahmed on 3/12/2018.
 */

public interface BusinessMvpPresenter <V extends BusinessMvpView> extends MvpPresenter<V> {
}
