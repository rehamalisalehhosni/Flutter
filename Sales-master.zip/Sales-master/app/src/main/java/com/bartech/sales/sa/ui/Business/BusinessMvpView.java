package com.bartech.sales.sa.ui.Business;

import com.bartech.sales.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/12/2018.
 */

public interface BusinessMvpView extends MvpView {

}
