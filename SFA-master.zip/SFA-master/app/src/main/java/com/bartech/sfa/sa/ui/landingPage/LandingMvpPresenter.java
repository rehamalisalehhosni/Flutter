package com.bartech.sfa.sa.ui.landingPage;

import com.bartech.sfa.sa.ui.base.MvpPresenter;

/**
 * Created by Ahmed on 3/7/2018.
 */

public interface LandingMvpPresenter<V extends LandingMvpView> extends MvpPresenter<V> {

}
