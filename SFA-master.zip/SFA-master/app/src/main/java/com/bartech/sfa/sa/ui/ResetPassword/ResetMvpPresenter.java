package com.bartech.sfa.sa.ui.ResetPassword;

import com.bartech.sfa.sa.ui.base.MvpPresenter;

/**
 * Created by Ahmed on 3/7/2018.
 */

public interface ResetMvpPresenter<V extends ResetMvpView> extends MvpPresenter<V> {

}
