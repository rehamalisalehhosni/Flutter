package com.bartech.sfa.sa.ui.Registration;

import com.bartech.sfa.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 2/21/2018.
 */

public interface RegisterMvpView extends MvpView {

void goToVerificationCode();

void openGoogleMaps();

void openAttachFile();
}
