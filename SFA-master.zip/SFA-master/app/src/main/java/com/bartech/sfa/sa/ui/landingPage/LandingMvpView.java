package com.bartech.sfa.sa.ui.landingPage;

import com.bartech.sfa.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/7/2018.
 */

public interface LandingMvpView extends MvpView {

void onCreateAccountClicked();

void onLoginClicked();

void onForgotPasswordClicked();


}
