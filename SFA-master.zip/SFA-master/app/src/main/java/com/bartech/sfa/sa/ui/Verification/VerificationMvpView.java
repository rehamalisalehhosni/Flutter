package com.bartech.sfa.sa.ui.Verification;

import com.bartech.sfa.sa.ui.base.MvpView;

/**
 * Created by Ahmed on 3/8/2018.
 */

public interface VerificationMvpView extends MvpView {
}
